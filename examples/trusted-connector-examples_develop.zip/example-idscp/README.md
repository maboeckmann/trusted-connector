This example demonstrates the conversion of MQTT messages (using Eclipse Paho)
and publishing via a web interface using the Trusted Connector.

Documentation is located at https://industrial-data-space.github.io/trusted-connector-documentation/docs/rest/

(c) Fraunhofer AISEC 2018